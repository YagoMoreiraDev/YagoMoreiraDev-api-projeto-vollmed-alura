package com.yagocloud.api_voll_med;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiVollMedApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiVollMedApplication.class, args);
	}

}
