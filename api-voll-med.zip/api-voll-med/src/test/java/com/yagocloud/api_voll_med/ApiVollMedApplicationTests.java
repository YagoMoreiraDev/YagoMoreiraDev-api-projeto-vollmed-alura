package com.yagocloud.api_voll_med;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiVollMedApplicationTests {

	@Test
	void contextLoads() {
	}

}
